public class SwipeDetails {
  private String swiper;
  private String swipee;
  private String comment;
  private boolean isLike;


  public String getSwiper() {
    return swiper;
  }

  public String getSwipee() {
    return swipee;
  }

  public String getComment() {
    return comment;
  }

  public void setSwiper(String swiper) {
    this.swiper = swiper;
  }

  public boolean getLike() {
    return isLike;
  }

  public void setLike(boolean like) {
    isLike = like;
  }
}
