import static com.mongodb.client.model.Filters.eq;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import io.lettuce.core.RedisClient;
import io.lettuce.core.SetArgs;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.reactive.RedisReactiveCommands;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.bson.Document;
import com.mongodb.MongoClient;
import reactor.core.publisher.Mono;


@WebServlet(name = "StatsServlet", value = "/StatsServlet")
public class StatsServlet extends HttpServlet {
  private static MongoClient mongoClient;
  private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
  private static final int REDIS_KEY_EXPIRATION_SECONDS = 300; // 5 minutes
  private static StatefulRedisConnection<String, String> connection;
  private static RedisReactiveCommands<String, String> redisCommands;
  private static RedisClient redisClient;

  @Override
  public void init() throws ServletException{
    super.init();
    try {
      String uri = "mongodb://admin:admin@35.87.116.245:27017/?maxPoolSize=50"; // ec2 mongodb public ip
      // Create MongoDB client
      if(mongoClient == null) {
        MongoClientURI mongoClientURI = new MongoClientURI(uri);
        mongoClient = new com.mongodb.MongoClient(mongoClientURI);
      }

    } catch (MongoException me) {
      System.err.println("Cannot create MongoClient for StatsServlet: " + me);
    }

    // Create Redis client
    if (redisClient == null) {
      redisClient = RedisClient.create("redis://localhost:6379"); // TODO: Replace Redis ec2 ip
      connection = redisClient.connect();
      redisCommands = connection.reactive();
    }
  }

  public void destroy() {
    connection.close();
    redisClient.shutdown();
    super.destroy();
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
    res.setContentType("application/json");
    ResponseMsg responseMsg = new ResponseMsg();

    Integer swiperId = ValidatePathAndNumber.validatePath(req, res, responseMsg);

    if (swiperId == null) {
      return;
    }

    MongoDatabase database = mongoClient.getDatabase("admin");
    MongoCollection<Document> statsCollection = database.getCollection("stats");

    fetchStats(statsCollection, swiperId, responseMsg, res);
  }

//  private Integer validatePath(HttpServletRequest req, HttpServletResponse res,
//      ResponseMsg responseMsg) throws IOException {
//    String urlPath = req.getPathInfo();
//    if (urlPath == null || urlPath.isEmpty()) {
//      responseMsg.setMessage("Missing Parameter");
//      res.setStatus(HttpServletResponse.SC_NOT_FOUND);
//      res.getOutputStream().print(gson.toJson(responseMsg));
//      res.getOutputStream().flush();
//      return null;
//    }
//
//    String[] urlParts = urlPath.split("/");
//    if (!isValidNumber(urlParts[1])) {
//      responseMsg.setMessage("Invalid url parameter: should be an ID");
//      res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
//      res.getOutputStream().print(gson.toJson(responseMsg));
//      res.getOutputStream().flush();
//      return null;
//    }
//
//    return Integer.parseInt(urlParts[1]);
//  }
//
//  private boolean isValidNumber(String s) {
//    if (s == null || s.isEmpty()) return false;
//    try {
//      int digits = Integer.parseInt(s);
//    } catch (NumberFormatException e) {
//      return false;
//    }
//    return true;
//  }

  //: this code works well for fetchStats, below code just add redis feature
//  private void fetchStats(MongoCollection<Document> collection, Integer swiperId,
//      ResponseMsg responseMsg, HttpServletResponse res)
//      throws IOException {
//    Document doc = collection.find(eq("swiper", swiperId)).first();
//
//    if (doc == null) {
//      responseMsg.setMessage("User Not Found");
//      res.setStatus(HttpServletResponse.SC_NOT_FOUND);
//      res.getOutputStream().print(gson.toJson(responseMsg));
//      res.getOutputStream().flush();
//      System.out.println("User Not Found:" + swiperId);
//    } else {
//      int likes = doc.getInteger("numLikes");
//      int dislikes = doc.getInteger("numDislikes");
//      Stats stats = new Stats().numLikes(likes).numDislikes(dislikes);
//      res.setStatus(HttpServletResponse.SC_OK);
//      res.getWriter().print(gson.toJson(stats));
//      res.getWriter().flush();
//    }
//  }

  private void fetchStats(MongoCollection<Document> collection, Integer swiperId,
      ResponseMsg responseMsg, HttpServletResponse res) {
    String redisKey = "user_stats:" + swiperId;

    redisCommands.get(redisKey)
        .switchIfEmpty(Mono.defer(() -> {
          Document doc = collection.find(eq("swiper", swiperId)).first();

          if (doc == null) {
            return AbstractGetMono.getMono(responseMsg, res, gson);
          } else {
            int likes = doc.getInteger("numLikes");
            int dislikes = doc.getInteger("numDislikes");
            Stats stats = new Stats().numLikes(likes).numDislikes(dislikes);
            String statsJson = gson.toJson(stats);

            // Store the JSON string in Redis
            return redisCommands.set(redisKey, statsJson) // store json string in redis cache
                .then(redisCommands.expire(redisKey, REDIS_KEY_EXPIRATION_SECONDS))
                .thenReturn(statsJson);
          }
        }))
        .doOnNext(statsJson -> { // // When the data is fetched from either Redis or MongoDB
          // Deserialize the JSON string into a Stats object
          Stats stats = gson.fromJson(statsJson, Stats.class);
          res.setStatus(HttpServletResponse.SC_OK);
          try { //  write json to res
            res.getWriter().print(gson.toJson(stats));
          } catch (IOException e) {
            throw new RuntimeException(e);
          }
          try {
            res.getWriter().flush();
          } catch (IOException e) {
            throw new RuntimeException(e);
          }
        })
        .block(); // Block and wait for the operation to complete before returning
  }
}
